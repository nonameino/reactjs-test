import React from 'react';

const EventNPromotionals = ()=>{
    return (
        <div style={{width: '100vw', height: '100vh', backgroundColor: '#D8EDFF'}}>

        </div>
    )
}

export default EventNPromotionals;